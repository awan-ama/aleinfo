package com.awanama.aleinfo.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.awanama.aleinfo.navigation.TopLevelDestination
import com.awanama.aleinfo.ui.theme.Green50
import com.awanama.aleinfo.ui.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onRegisterClick: () -> Unit,
    modifier: Modifier = Modifier,
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val username = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val isLoggedIn by authViewModel.isLoggedIn.collectAsState()
    val loginError by authViewModel.loginError.collectAsState()
    val usernameError = remember { mutableStateOf(false) }
    val passwordError = remember { mutableStateOf(false) }

    if (isLoggedIn) {
        onLoginSuccess()
    }

    Scaffold {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(it),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = username.value,
                onValueChange = {
                    username.value = it
                    usernameError.value = it.isEmpty()
                },
                label = { Text(text = "Username") },
                isError = usernameError.value,
            )
            if (usernameError.value) {
                Text(text = "Username cannot be empty", color = MaterialTheme.colorScheme.error)
            }

            OutlinedTextField(
                value = password.value,
                onValueChange = {
                    password.value = it
                    passwordError.value = it.isEmpty()
                },
                label = { Text(text = "Password") },
                modifier = Modifier.padding(vertical = 10.dp),
                isError = passwordError.value,
            )
            if (passwordError.value) {
                Text(text = "Password cannot be empty", color = MaterialTheme.colorScheme.error)
            }

            if (loginError != null) {
                Text(text = loginError!!, color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = {
                    if (!usernameError.value && !passwordError.value) {
                        authViewModel.login(username.value, password.value)
                    }
                },
                modifier = Modifier.padding(vertical = 5.dp)
            ) {
                Text(text = "Login")
            }

            Button(
                onClick = onRegisterClick,
                colors = ButtonDefaults.buttonColors(Green50),
                modifier = Modifier.padding(vertical = 5.dp)
            ) {
                Text(text = "Register Account")
            }
        }
    }
}

@Composable
fun LoginRoute(
    onNavigateClick: (source: String) -> Unit
) {
    LoginScreen(
        onLoginSuccess = { onNavigateClick(TopLevelDestination.Home.route) },
        onRegisterClick = { onNavigateClick(TopLevelDestination.Register.route) }
    )
}

@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    LoginScreen(onLoginSuccess = {}, onRegisterClick = {})
}
