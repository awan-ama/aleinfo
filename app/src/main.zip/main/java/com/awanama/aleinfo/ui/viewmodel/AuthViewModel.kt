package com.awanama.aleinfo.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.awanama.aleinfo.data.entity.User
import com.awanama.aleinfo.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError

    private val _registerError = MutableStateFlow<String?>(null)
    val registerError: StateFlow<String?> = _registerError

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val user = userRepository.getUser(username, password)
            if (user != null) {
                _isLoggedIn.value = true
                _loginError.value = null
            } else {
                _isLoggedIn.value = false
                _loginError.value = "Invalid username or password"
            }
        }
    }

    fun register(username: String, email: String, password: String) {
        viewModelScope.launch {
            val existingUser = userRepository.getUser(username = username, password = password)
            if (existingUser != null) {
                _registerError.value = "Already exists"
            }

            val user = User(username = username, email = email, password = password)
            userRepository.insertUser(user)
            _isLoggedIn.value = true
            _registerError.value = null
        }
    }
}
