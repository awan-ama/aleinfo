package com.awanama.aleinfo.utility

object Constants {
    const val API_BASE_URL = "https://api.sampleapis.com/"
    const val SOURCE = "source"
}