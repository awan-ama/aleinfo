//package com.awanama.aleinfo.data
//
//import androidx.room.Database
//import androidx.room.RoomDatabase
//import com.awanama.aleinfo.data.dao.UserDao
//import com.awanama.aleinfo.data.entity.User
//
//@Database(
//    entities = [User::class],
//    version = 1
//)
//
//abstract class UserDatabase: RoomDatabase() {
//    abstract val dao: UserDao
//}